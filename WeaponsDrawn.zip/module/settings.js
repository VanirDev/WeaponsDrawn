import { DND5E } from "../../../systems/dnd5e/module/config.js";

export const registerSettings = function () {
	// game.settings.register("VariantEncumbrance", "lightMultiplier", {
	// 	name: "Unencumbered Strength Multiplier",
	// 	hint: "Multiplier used to calculate maximum carrying weight before being encumbered from the strength ability score.",
	// 	scope: "world",
	// 	config: true,
	// 	type: Number,
	// 	default: 5
	// });
};
