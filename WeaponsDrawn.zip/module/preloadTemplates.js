export const preloadTemplates = async function () {
	const templatePaths = [
		// Add paths to "modules/WeaponsDrawn/templates"
	];
	return loadTemplates(templatePaths);
};